package com.example.ipirate

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.AlarmClock
import com.google.gson.Gson
import kotlinx.android.synthetic.main.activity_display_movies.*
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.*
import androidx.recyclerview.widget.LinearLayoutManager
import java.io.FileNotFoundException
import kotlin.system.exitProcess

data class TVTMDBExternalIDs(val imdb_id: String, val tvdb_id: String)
data class TMDBDetailed(val number_of_seasons: Int, val number_of_episodes: Int)

class DisplayTVActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_display_tvshows)
        recyclerView.layoutManager = LinearLayoutManager(this)
        input = intent.getStringExtra(AlarmClock.EXTRA_MESSAGE)!!
        getTVShow()
        val descriptions = mutableListOf<String>()
        val titles = mutableListOf<String>()
        val releases = mutableListOf<String>()
        val ratings = mutableListOf<String>()
        val tmdbIds = mutableListOf<String>()
        val imdbIds = mutableListOf<String>()
        val tvdbIds = mutableListOf<String>()
        val seasons = mutableListOf<String>()
        val episodes = mutableListOf<String>()
        //val posters = mutableListOf<String>()
        val posters: ArrayList<String> = ArrayList()
        var count = 0
        for (i in tvOutputMap) {
            count += 1
            descriptions.add(i["description"].toString())
            titles.add(i["title"].toString())
            releases.add(i["release"].toString())
            ratings.add(i["rating"].toString())
            tmdbIds.add(i["tmdbId"].toString())
            imdbIds.add(i["imdbId"].toString())
            tvdbIds.add(i["tvdbId"].toString())
            seasons.add(i["seasons"].toString())
            episodes.add(i["episodes"].toString())
            posters.add(i["poster"].toString())
        }
        recyclerView.adapter = RecyclerAdapterTV(posters, titles.toTypedArray(), releases.toTypedArray())
    }


    private var input = ""
    private var tvOutputString = mutableListOf<String>()
    private var tvOutputMap = mutableListOf<Map<String, String>>()

    private fun getTVShow() = runBlocking {
        withContext(Dispatchers.IO) {
            val url =
                URL("https://api.themoviedb.org/3/search/tv?api_key=${Globals.tmdbAPI}&query=$input")
            with(url.openConnection() as HttpURLConnection) {
                requestMethod = "GET"
                val dirtyJson = inputStream.bufferedReader().use {
                    it.readText()
                }
                val gson = Gson()
                val tv: TMDBClean = gson.fromJson(dirtyJson, TMDBClean::class.java)
                val tvList = tv.results
                for (i in tvList) {
                    var newDirtyJson = ""
                    val tvData: TMDBData = gson.fromJson(i, TMDBData::class.java)
                    val tmdbIdStr = tvData.id.toString()
                    var imdbId = ""
                    var tvdbId = ""

                    try {
                        val newUrl =
                            URL("https://api.themoviedb.org/3/tv/$tmdbIdStr/external_ids?api_key=${Globals.tmdbAPI}&language=en-US")
                        with(newUrl.openConnection() as HttpURLConnection) {
                            requestMethod = "GET"
                            newDirtyJson = inputStream.bufferedReader().use {
                                it.readText()
                            }
                        }
                    val externals: TVTMDBExternalIDs =
                        gson.fromJson(newDirtyJson, TVTMDBExternalIDs::class.java)
                    imdbId = externals.imdb_id
                    tvdbId = externals.tvdb_id
                    } catch (e: FileNotFoundException) {}

                    var seasons = ""
                    var episodes = ""
                    try {
                        val newUrl2 =
                            URL("https://api.themoviedb.org/3/tv/$tmdbIdStr?api_key=${Globals.tmdbAPI}&language=en-US")
                        with(newUrl2.openConnection() as HttpURLConnection) {
                            requestMethod = "GET"
                            newDirtyJson = inputStream.bufferedReader().use {
                                it.readText()
                            }
                        }
                        val detailed: TMDBDetailed =
                            gson.fromJson(newDirtyJson, TMDBDetailed::class.java)
                        seasons = detailed.number_of_seasons.toString()
                        episodes = detailed.number_of_episodes.toString()
                    } catch (e: FileNotFoundException) {}

                    val title = tvData.title
                    val release = tvData.release_date
                    val rating = tvData.vote_average.toString()
                    val tmdbId = tvData.id.toString()
                    val description = tvData.overview
                    val poster =
                        tvData.poster_path
                    tvOutputMap.add(
                        mapOf(
                            "title" to title, "release" to release, "rating" to rating,
                            "tmdbId" to tmdbId, "imdbId" to imdbId, "tvdbId" to tvdbId,
                            "episodes" to episodes, "seasons" to seasons,
                            "description" to description, "poster" to poster
                        )
                    )
                    tvOutputString.add("$title \n Released: $release \n Rating: $rating \n TMDB ID: $tmdbId " +
                            "\n IMDB ID: $imdbId TVDB ID: $tvdbId \n Seasons: $seasons \n Episodes: $episodes " +
                            "\n $description \n \n")
                }
            }
        }
    }
}

