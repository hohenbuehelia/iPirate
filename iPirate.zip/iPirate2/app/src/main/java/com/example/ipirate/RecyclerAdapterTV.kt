package com.example.ipirate

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso
import java.lang.System.exit
import kotlin.system.exitProcess

class RecyclerAdapterTV(
    private val posterUrls: ArrayList<String> = ArrayList(),
    private val titles: Array<String> = arrayOf(),
    private val dates: Array<String> = arrayOf()) : RecyclerView.Adapter<PhotoHolderTV>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PhotoHolderTV {
        val imageItem = LayoutInflater.from(parent.context).inflate(R.layout.activity_display_tvshows, parent, false)
        return PhotoHolderTV(imageItem)
    }

    override fun getItemCount(): Int {
        return posterUrls.size
    }

    override fun onBindViewHolder(holder: PhotoHolderTV, position: Int) {
        val posterUrl = posterUrls[position]
        // val title = titles[position]
        // val date = dates[position]
        holder.updateWithUrl("https://image.tmdb.org/t/p/w500/$posterUrl")
    }
}

class PhotoHolderTV(v: View) : RecyclerView.ViewHolder(v) {

    private val tvImage: ImageView = v.findViewById(R.id.tvImage)
    // private val tvTitle: TextView = v.findViewById(R.id.tvTitle)
    // private val tvDate: TextView = v.findViewById(R.id.tvDate)
    private var posterUrlString = String()

    fun updateWithUrl(url: String) {
        Picasso.get().load(url).error(R.drawable.no_poster).placeholder(R.drawable.tpb_logo).into(tvImage)
        // tvTitle.text = title
        // tvDate.text = date
        // posterUrlString = urlstring
    }
}