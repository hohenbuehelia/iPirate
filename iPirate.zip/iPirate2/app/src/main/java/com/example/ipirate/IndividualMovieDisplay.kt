package com.example.ipirate

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class IndividualMovieDisplay : AppCompatActivity() {

    companion object {
        const val EXTRA_MOVIE_PHOTO = "IndividualMovieDisplay.EXTRA_MOVIE_PHOTO"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_individual_movies)
    }
}